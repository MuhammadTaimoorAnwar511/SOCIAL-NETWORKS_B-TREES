#include<iostream>
#include<fstream>
#include<string>
#include <climits>
#include <sstream>
#include"Header.h"
using namespace std;

int main()
{
	friend_link_list frnd;
	bool i_d = 0;//insert down//
	bool i_r = 0;//inser right//
	int x, y;
	//open file//

	fstream frndfile;
	frndfile.open("friends.txt", ios::in);//read

	//variables part 2//
	int opt = 1;//controlll menu//
	int n;//store char as intger//
	int num = 0;//for combining character
	int traverse = 0;//for controll traversal of 500 people//
	int l;// length of string//
	int f;// first space after://
	int c_c = 1;//character count;
	string s;// read string from file//
	string word = "";//separate string after ://
	char ch;//store character from string //and seperate word after space //
	bool controll_iteration = 0;
	int count_loop = 0;


	if (frndfile.is_open())
	{
		while (getline(frndfile, s))//read line by line 
		{
			word = "";//initial string

			for (auto x : s)
			{
				if (x == ':')//add main person down to list//
				{
					i_d = 1;
					i_r = 0;
					n = stoi(word);
					frnd.add_person(n, i_d, i_r);
					//	 cout << n<<" ]" << endl;
					word = "";
				}
				else
				{
					word = word + x;
				}
			}

			l = word.length();//store  lenght of each line
			f = 1;// first space after : //

			for (int i = 0; i < l; i++)
			{
				ch = word.at(i);//convert character one by one //

				if (f == 1)// first space after : //
				{
					f = 0;
				}

				else if (ch == ' ') //Check space after each character//
				{
					// cout << " ->";
				}

				else
				{
					if (c_c == 1)//first character//
					{
						n = int(ch) - 48;
						num = num + (n * 1000);
						c_c++;
					}
					else if (c_c == 2)//second character//
					{
						n = int(ch) - 48;
						num = num + (n * 100);
						c_c++;
					}
					else if (c_c == 3)//third character//
					{
						n = int(ch) - 48;
						num = num + (n * 10);
						c_c++;
					}
					else if (c_c == 4)//fourth character//
					{
						n = int(ch) - 48;
						num = num + (n * 1);

						i_d = 0;
						i_r = 1;
						//	 cout << num << "";
						frnd.add_person(num, i_d, i_r);
						c_c = 1;
						num = 0;
					}
				}
			}
		}
	}
	frndfile.close();
	/////////////////////////////////////////////////////////PART 1//////////////////////////////////////////////////////////

	//variables part 1//
	BplusTree_id b;

	int  key = 0, flag, i = 1, j = 42;
	string  str;

	string s1;
	int n_length;
	int  seven_count = 1;
	int key_id=0;
	string full_name;
	string date_birth;
	string reg_date;
	string address;
	string qualification;
	string gender;

	int r1,r2;
	int total_id_12=6600;
	fstream firstfile,secondfile,thirdfile,fourthfile,fivefile,sixfile,sevenfile,eightfile,ninefile,tenfile,elevenfile,twelvefile;
	fstream writing_file;

	firstfile.open("Fall2022DSDataFile001.txt", ios::in);//read
	secondfile.open("Fall2022DSDataFile002.txt", ios::in);//read
	thirdfile.open("Fall2022DSDataFile003.txt", ios::in);//read
	fourthfile.open("Fall2022DSDataFile004.txt", ios::in);//read
	fivefile.open("Fall2022DSDataFile005.txt", ios::in);//read
	sixfile.open("Fall2022DSDataFile006.txt", ios::in);//read
	sevenfile.open("Fall2022DSDataFile007.txt", ios::in);//read
	eightfile.open("Fall2022DSDataFile008.txt", ios::in);//read
	ninefile.open("Fall2022DSDataFile009.txt", ios::in);//read
	tenfile.open("Fall2022DSDataFile010.txt", ios::in);//read
	elevenfile.open("Fall2022DSDataFile011.txt", ios::in);//read
	twelvefile.open("Fall2022DSDataFile012.txt", ios::in);//read

	writing_file.open("single.txt", ios::out);//writing in file//

	//variables part 1//
	//////////////////////////////////////////////////////////////reading file 01////////////////////////////////////////////////////
	if (writing_file.is_open())
	{
		
		// first file //

		if (firstfile.is_open())
		{
		//	cout << "\nfirst\n";
			while (getline(firstfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{		
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word
					
						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;
						
						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}

		//second file 
		seven_count = 1;

		if (secondfile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(secondfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}

		//third file 
		seven_count = 1;

		if (thirdfile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(thirdfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		
		//fourth file 
		seven_count = 1;

		if (fourthfile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(fourthfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}

		//five file 
		seven_count = 1;

		if (fivefile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(fivefile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		/*
		//six file 
		seven_count = 1;

		if (sixfile.is_open())
		{
			//cout << "\nsixth\n";
			//system("pause");

			while (getline(sixfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		/*
		
		//seven file 
		seven_count = 1;

		if (sevenfile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(sevenfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		
		//eight file 
		seven_count = 1;

		if (eightfile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(eightfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		



		//nine file 
		seven_count = 1;

		if (ninefile.is_open())
		{
			cout << "\n NINE FILE \n";
			//system("pause");

			while (getline(ninefile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		
		//ten file 
		seven_count = 1;

		if (tenfile.is_open())
		{
		//	cout << "\nsecond\n";
			//system("pause");

			while (getline(tenfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		//eleven file 
		seven_count = 1;

		if (elevenfile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(elevenfile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		//twelve file 
		seven_count = 1;

		if (twelvefile.is_open())
		{
			//cout << "\nsecond\n";
			//system("pause");

			while (getline(twelvefile, s1))//read line by line 
			{
				seven_count = 1;
				//cout << s << endl;
				n_length = s1.length();
				for (int i = 0; i < n_length; i++)
				{
					// Check if the current iteration is equal to ' ' or
					// it's the last character
					if (s1[i] == '\t' || i == (n_length - 1))
					{
						if (seven_count == 1)
						{
							//cout << "count " << seven_count << endl;
							key_id = stoi(word + s1[i]);
							writing_file << key_id << "\t";
							//cout << "id = "<< key_id <<endl;
							word = "";
						}

						else if (seven_count == 2)
						{
							//cout << "count " << seven_count << endl;
							full_name = word + s1[i];
							writing_file << full_name << "\t";
							//cout << full_name << endl;
							word = "";
						}
						else if (seven_count == 3)
						{
							//cout << "count " << seven_count << endl;
							date_birth = word + s1[i];
							writing_file << date_birth << "\t";
							//cout << date_birth << endl;
							word = "";
						}
						else if (seven_count == 4)
						{
							//cout << "count " << seven_count << endl;
							gender = word + s1[i];
							writing_file << gender << "\t";
							//cout << gender << endl;
							word = "";
						}
						else if (seven_count == 5)
						{
							//cout << "count " << seven_count << endl;
							reg_date = word + s1[i];
							writing_file << reg_date << "\t";
							//cout << reg_date << endl;
							word = "";
						}
						else if (seven_count == 6)
						{
							//cout << "count " << seven_count << endl;
							address = word + s1[i];
							writing_file << address << "\t";
							//cout << address << endl;
							word = "";
						}
						else if (seven_count == 7)
						{
							//cout << "count " << seven_count << endl;
							qualification = word + s1[i];
							writing_file << qualification << endl;
							//cout << qualification << endl;
							word = "";
						}

						// Print word

						//writing_file << full_name << "\t";
						//writing_file << date_birth << "\t";
						//writing_file << gender << "\t";
						//writing_file << reg_date << "\t";
						//writing_file << address << "\t";
						//writing_file << qualification << endl;

						b.add(key_id, full_name, date_birth, reg_date, address, qualification, gender);
						//cout << "id = " << key_id << endl;
						//cout << full_name << endl;
						//cout << date_birth << endl;
						//cout << gender << endl;
						//cout << reg_date << endl;
						//cout << address << endl;
						//cout << qualification << endl;

						seven_count++;
						word = "";
						//	break;
					}
					// Add current character in word string
					else
					{
						word += s1[i];
					}
				}
			}
		}
		*/
		

	}

	//writing_file.close();


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n==================================================================================================================";
	cout << "===================================================================================================================\n";
	
	while (opt == 1)
	{
		do
		{
			cout << "\n1 ] PERSON WITH BIGEST SOCIAL CIRCLE\n2] SHOW WHOLE LIST \n3]FIND COMMON FRND BETWEEN TWO PERSONS\n4] MEETING POSSIBILY\n5] FIND SOCIAL DISTANCE\n";
			cout << "\n6 ] ADD KEY TO BTREE\n7] SEARCH SPECIFIC KEY\n8]DISPLAY BPLUS TREE \n9] SEARCH BETWEEN RANGE OF TWO ID\n10] & operator  BETWEEN ID\n";
			cout << "  11] OR OPERATOR BETWEEN ID\n12] NOT OPERATOR BETWEEN ID  \n =";
			cin >> opt;

		} while (opt <= 0 || opt >= 13);

		switch (opt)
		{
		case 1:

			for (int i = 0; i < 2500; i++)
			{
				traverse = i + 2001;
				//cout << "\n=================================================================================";
				//cout << "===================================PERSON FIND===================================\n";
				frnd.find_social_circle_of_specific_person(traverse);//find social circle for each person//

				//cout << "\n=================================================================================";
				//cout << "================ ID " << traverse << "  = DIRECT FRND =====================================\n";
				frnd.show_frnd_direct_list();//out frnd in social circle

				//cout << "\n\n\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$DELETED$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n\n";
				frnd.delete_frnd_direct_list();//delete and get ready for next loop//
				//cout << " total frnd of person id " << traverse << " " << total_frnd_specific_person << endl;
				frnd.set_specific_person_social_circle(traverse);//set total number of frnd in social circle//
				total_frnd_specific_person = 0;// ready fro next loop to count total frnd//
			}

			cout << "\n=================================================================================";
			cout << "\n============================== LARGEST SOCIAL CIRCLE =============================================\n";
			frnd.get_person_with_largest_social_circle();//output person with largest social circle//
			break;

		case 2:
			cout << "\n=================================================================================";
			cout << "\n================================WHOLE LIST ======================================\n";
			frnd.show_whole_list_frnd();
			break;

		case 3:
			do
			{
				cout << "\nenter first person id\n=";
				cin >> x;
			} while (x <= 2000 || x >= 2501);
			do
			{
				cout << "\nenter second person id\n=";
				cin >> y;
			} while (y<= 2000 || y >= 2501);

			//cout << "\n******************************************************************************\n";
			frnd.find_social_circle_of_specific_person_First(x);//find social circle for first person//
			frnd.find_social_circle_of_specific_person_Second(y);//find social circle for second person//
			//cout << "\n*********************************** FIRST *************************************\n";
			frnd.show_frnd_direct_list_first();//output first person social circle frnds//
			//cout << "\n************************************ SECOND *************************************\n";
			frnd.show_frnd_direct_list_second();//output second person social circle frnds//
			cout << "\n************************************ COMMON FRNDS *************************************\n";
			frnd.common_frnd_insocial_circle(0);//output first and second person common social circle frnds//

			cout << "\nTotal number of common friends = " << total_common_frnd << endl;
			frnd.delete_frnd_direct_list_First();// free link_list  for next loop
			frnd.delete_frnd_direct_list_Second();// free link_list  for next loop
			total_common_frnd = 0;

			break;

		case 4:

			//return 0;//hence no need to iterate//
			 controll_iteration=0;
			 count_loop = 0;
			
			for (int x = 2001; x <= 2499; x++)
			{		
				for (int y = x + 1; y <= 2500; y++)
				{
					count_loop = count_loop + 1;
					//cout << "\n******************************************************************************\n";
					frnd.find_social_circle_of_specific_person_First(x);//find social circle for first person//
					frnd.find_social_circle_of_specific_person_Second(y);//find social circle for second person//
					//cout << "\n*********************************** FIRST *************************************\n";
					frnd.show_frnd_direct_list_first();//output first person social circle frnds//
					//cout << "\n************************************ SECOND *************************************\n";
					frnd.show_frnd_direct_list_second();//output second person social circle frnds//
					//cout << "\n************************************ COMMON FRNDS *************************************\n";
					frnd.common_frnd_insocial_circle(1);//output first and second person common social circle frnds//

					//cout << "\nTotal number of common friends = " << total_common_frnd << endl;
					frnd.delete_frnd_direct_list_First();// free link_list  for next loop
					frnd.delete_frnd_direct_list_Second();// free link_list  for next loop

					if (total_common_frnd == 0)
					{
						cout << x << "\nNEVER MEET \n" << y << endl;
						controll_iteration = 1;
						system("pause");
					}
					else
					{
						//	cout << "\ncommon friends hain bhai \n";
					}
					total_common_frnd = 0;
				}
				//cout << endl;
			}
			//cout << "\n*****************************MEETING QUEUE***********************************\n";
			//frnd.show_meeting_qeue();
			if (controll_iteration == 0)
			{
				cout   << "\n EVERY ONE HAS POSIBILITY TO MEET EVERY ONE  \n" << endl;
				//cout << count_loop << endl;
			}
			else
			{
				
			}
			break;
			
		case 5:
			
			do
			{ 
			cout << "\nenter first person id\n="; 
			cin >> x;
			} while (x <= 2000 || x >= 2501);
			
			do
			{ 
			cout << "\nenter second person id\n=";
			cin >> to_find;
			} while (to_find <= 2000 || to_find >= 2501);

			cout << "\n=============== PASSING ====================\n";
			frnd.pass_id_to_qeue(x);
			cout << "\n=============== qeue simple =======================\n";
			frnd.show_qeue(1);
			cout << "\n=============== traversed =======================\n";
			frnd.show_traversed();
			cout << "from " << x << " to " << to_find << endl;
			cout << "\nSOCIAL DISTANCE = " << level;
			level = 0;
			level_id = 0;
			level_time = 1;
			cout << "\n=============== DELETE =======================\n";
			frnd.delete_traversed();
			frnd.delete_qeue();

			break;
			///////////////////////////////////PART 1/////////////////////////////////////////
		case 6:
			total_id_12 = total_id_12 + 1;
				cout << "Enter the ID to be added: " << endl;
				cin >> key;
				writing_file << key << "\t";
				cout << "Enter the FULL NAME to be added: " << endl;
				cin >> full_name;
				cin.ignore();
				getline(cin, full_name);
				writing_file << full_name << "\t";
				cout << "Enter the DATE OF BIRTH to be added: " << endl;
				cin >> date_birth;
				writing_file << date_birth << "\t";
				cout << "Enter the DATE OF REGESTRATION to be added: " << endl;
				cin >> reg_date;
				writing_file << reg_date << "\t";
				cout << "Enter the ADDRESS to be added: " << endl;
				cin >> address;
				writing_file << address << "\t";
				cout << "Enter the QUALIFICATION to be added: " << endl;
				cin >> qualification;
				writing_file << qualification << "\t";
				cout << "Enter the GENDER to be added: " << endl;
				cin >> gender;
				writing_file << gender << "\t";

				b.add(key,full_name,date_birth,reg_date,address,qualification,gender);

			break;

		case 7:

			cout << "Enter the ID to be found: ";
			cin >> key;
			b.search_specific_element(key);
			break;

		case 8:
			b.display_tree(b.getRoot_val());
			break;
		case 9:
		
			cout << "enter range\n";
			
			do
			{
			cout << "from id \n =";
			cin >> r1;
			} while (r1 <= -1 || r1 > total_id_12);

			do
			{
			 cout << "to id \n =";
			 cin >> r2;
			} while (r2 <= -1 || r2 > total_id_12);
			
			cout << "\n=================================================================================";
			cout << "\n================================ SEARCH SPECIFIC ELEMENT  ======================================\n";
			for (int i = r1; i <= r2; i++)
			{
				b.search_specific_element(i);
			}
			break;

		case 10:
		
			do
			{
				cout << "ENTER FIRST  id \n =";
				cin >> r1;
			} while (r1 <= -1 || r1 > total_id_12);

			do
			{
				cout << "ENTER SECOND  id \n =";
				cin >> r2;
			} while (r2 <= -1 || r2 > total_id_12);

			cout << "\n=================================================================================";
			cout << "\n================================ && OPERATOR  ======================================\n";
				b.search_specific_element(r1);
				cout << "\n && \n";
				b.search_specific_element(r2);
		break;

		case 11:
			do
			{
				cout << "ENTER FIRST  id \n =";
				cin >> r1;
			} while (r1 <= -1 || r1 > total_id_12);

			do
			{
				cout << "ENTER SECOND  id \n =";
				cin >> r2;
			} while (r2 <= -1 || r2 > total_id_12);

			cout << "\n=================================================================================";
			cout << "\n================================ OR OPERATOR  ======================================\n";
			if (r1 < r2)
			{
            
			}
			else if (r1> r2)
			{
				r1 = r2;
			}
			else
			{
			}
			b.search_specific_element(r1);
			
			break;

		case 12:
			do
			{
				cout << " ENTER ID  TO SKIP \n =";
				cin >> r2;
			} while (r2 <= -1 || r2 > total_id_12 );
			cout << "\n=================================================================================";
			cout << "\n================================ NOT OPERATOR  ======================================\n";
			for (int i = 0; i <= total_id_12; i++)
			{
				if (i == r2)
				{

				}
				else
				{
					b.search_specific_element(i);
				}
			}
			break;
		}
		
		do
		{
			cout << "\n1] CONTINUE\n2] EXIT \n =";
			cin >> opt;
		} while (opt <= 0 || opt >= 3);

	}
	//frnd.delete_meeting_qeue();

	return 0;
}