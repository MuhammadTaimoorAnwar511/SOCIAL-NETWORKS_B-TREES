#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
#include <climits>
#include <sstream>
using namespace std;


/////////////////////////////////////////////////////PART 1/////////////////////////////////////////
const int MAX = 3000;

// BP node
class Node
{

public:
	bool leaf;// leaf node 
	int* id;
	string *full_name;
	string* dob;
	string* regd;
	string* adress;
	string* qualification;
	string* gender;

	int length;
	Node** down;

	Node()// initializing constructor//
	{
		id = new int[MAX];
		gender = new string[MAX];
		full_name = new string[MAX];
		dob = new string[MAX];
		regd = new string[MAX];
		adress = new string[MAX];
		qualification = new string[MAX];

		down = new Node * [MAX + 1];
	}
};


// BP tree
class BplusTree_id
{
public:

	Node* root;//declaring root 

	BplusTree_id() // initializing constructor//
	{
		root = NULL; //initiallyy root is null//
	}

	//search element //
	Node* search_specific_element(int x)
	{
		if (root == NULL) //if no element is present on b tree//
		{
			cout << "FIRST NODE\n";
			return NULL;
		}

		else // if tree is not empty//
		{
			Node* temp_cursor = root;

			int i = 0, j = 0, k = 0;

			while (temp_cursor->leaf == false)
			{

				while (i < temp_cursor->length)
				{
					if (i == temp_cursor->length - 1)//i euall to element length//
					{
						temp_cursor = temp_cursor->down[i + 1];//point to down //
						break;// if break
					}
					if (x < temp_cursor->id[i])
					{
						temp_cursor = temp_cursor->down[i];
						break;//if break
					}
					i++;
				}
			}

			while (j < temp_cursor->length)
			{
				if (temp_cursor->id[j] == x)//element found //
				{
//					cout << " Element Found \n =";
					cout << temp_cursor->id[j]<<"\n";//output valuess//
					cout << temp_cursor->full_name[j] << "\n";
					cout << temp_cursor->dob[j] << "\n";
					cout << temp_cursor->gender[j] << "\n";
					cout << temp_cursor->regd[j] << "\n";
					cout << temp_cursor->adress[j] << "\n";
					cout << temp_cursor->qualification[j] << "\n";

					return temp_cursor;//return value/exit loop//
				}
				j++;
			}
			while (k < temp_cursor->length)
			{
				if (temp_cursor->id[k] == x)// element found 
				{
		//			cout << "ELEMENT Found\n";
					cout << temp_cursor->id[k] << "\n";//output valuess//
					cout << temp_cursor->full_name[k] << "\n";
					cout << temp_cursor->dob[k] << "\n";
					cout << temp_cursor->gender[k] << "\n";
					cout << temp_cursor->regd[k] << "\n";
					cout << temp_cursor->adress[k] << "\n";
					cout << temp_cursor->qualification[k] << "\n";

					return temp_cursor;
				}
				k++;
			}

		//	cout << "   ELEMENT Not found\n";

			return NULL;
		}
	}
	//search element //

	//add element//
	void add(int x,string fn,string db, string rd, string addrs, string qual, string g)//add element on tree
	{
		if (search_specific_element(x))
		{
			return;
		}

		if (root == NULL)// first element  
		{
			cout << "\nELEMENT ADDED\n";
			root = new Node;

			root->id[0] = x;
			root->full_name[0] = fn;
			root->dob[0] = db;
			root->regd[0] = rd;
			root->adress[0] = addrs;
			root->qualification[0] = qual;
			root->gender[0] = g;

			root->leaf = true;
			root->length = 1;
		}

		else // if it is not first element //
		{
			int i = 0;
			Node* parent = NULL;
			Node* temp_cursor = root;


			while (temp_cursor->leaf == false)
			{
				parent = temp_cursor;//initalizing parent ///

				while (i < temp_cursor->length)
				{
					if (x >= temp_cursor->id[i])
					{

					}
					else
					{
						temp_cursor = temp_cursor->down[i];
						break;
					}
					i++;
				}

				i = 0;//initializing for next loop//
				while (i < temp_cursor->length)
				{
					if (x >= temp_cursor->id[i])//comparison//
					{

					}
					else
					{
						temp_cursor = temp_cursor->down[i];
						break;
					}
					if (i == temp_cursor->length - 1)//found
					{
						temp_cursor = temp_cursor->down[i + 1];
						break;
					}
					i++;
				}

			}

			if (temp_cursor->length < MAX) //comparision
			{
				int i = 0, j;//declare int 

				while (x > temp_cursor->id[i] && i < temp_cursor->length)
				{
					i++;
				}

				j = temp_cursor->length;//initalising j//

				while (j > i)
				{
					temp_cursor->id[j] = temp_cursor->id[j - 1];
					j--;
				}

				
				cout << "\nELEMENT ADDED \n";
				
				temp_cursor->id[i] = x;//store in id//
				temp_cursor->full_name[i] = fn;//store in full name/
				temp_cursor->dob[i] = db;// store in db//
				temp_cursor->regd[i] = rd;// store in reg date//
				temp_cursor->adress[i] = addrs;//store in adress//
				temp_cursor->qualification[i] = qual;// store in qualification//
				temp_cursor->gender[i] = g;//s tore i gender//
				

				temp_cursor->length++;//increment length
				temp_cursor->down[temp_cursor->length] = temp_cursor->down[temp_cursor->length - 1];
				temp_cursor->down[temp_cursor->length - 1] = NULL;
			}
			//
			else
			{
				int k = 0;//declaring variable//
				int virNode[MAX + 1];//array//
				string virnode_fm[MAX + 1]; //full name array//
				string virnode_dob[MAX + 1];// date of birth array//
				string virnode_regd[MAX + 1];// regestration array//
				string virnode_adress[MAX + 1];//address array//
				string virnode_qualif[MAX + 1];//qualification  array//
				string   virnode_gender[MAX + 1];//  gender array//
				int i = 0, j;

				Node* newleaf_node = new Node;//new element 


				while (k < MAX)
				{
					virNode[k] = temp_cursor->id[k];
					k++;
				}

				while (x > virNode[i] && i < MAX)
				{
					i++;
				}

				j = MAX + 1;

				while (j > i)
				{
					virNode[j] = virNode[j - 1];
					j--;
				}

				virNode[i] = x;//storing virnode[i]
				virnode_fm[i]=fn; //full name array//
				virnode_dob[i]=db;// date of birth array//
				virnode_regd[i]=rd;// regestration array//
				virnode_adress[i]=addrs;//address array//
				virnode_qualif[i]=qual;//qualification  array//
				virnode_gender[i]=g;//  gender array//

				newleaf_node->leaf = true;
				temp_cursor->length = (MAX + 1) / 2;//cal legth
				newleaf_node->length = MAX + 1 - (MAX + 1) / 2;//cal length
				temp_cursor->down[temp_cursor->length] = newleaf_node;
				newleaf_node->down[newleaf_node->length] = temp_cursor->down[MAX];
				temp_cursor->down[MAX] = NULL;

				i = 0;//starting new loop
				while (i < temp_cursor->length)//update temp id till < legth//
				{
					

					temp_cursor->id[i] = virNode[i];//updating 
					temp_cursor->full_name[i] = virnode_fm[i];//updating
					temp_cursor->adress[i] = virnode_adress[i];//updating
					temp_cursor->dob[i] = virnode_dob[i];//updating
					temp_cursor->regd[i] = virnode_regd[i];//updating
					temp_cursor->qualification[i] = virnode_qualif[i];//updating
					temp_cursor->gender[i] = virnode_gender[i];//updating

					i++;
				}

				i = 0;
				j = temp_cursor->length;
				//variable and new loop//
				while (i < newleaf_node->length)//update new leaf  id till < legth//
				{
					newleaf_node->id[i] = virNode[j];    //updating
					temp_cursor->full_name[i] = virnode_fm[j];//updating
					temp_cursor->adress[i] = virnode_adress[j];//updating
					temp_cursor->dob[i] = virnode_dob[j];//updating
					temp_cursor->regd[i] = virnode_regd[j];//updating
					temp_cursor->qualification[i] = virnode_qualif[j];//updating
					temp_cursor->gender[i] = virnode_gender[j];//updating
					
					i++;
					j++;
				}

				if (temp_cursor != root)
				{
					addInternal_node(newleaf_node->id[0], newleaf_node->full_name[0], newleaf_node->dob[0], newleaf_node->regd[0], newleaf_node->adress[0], newleaf_node->qualification[0], newleaf_node->gender[0],parent, newleaf_node);
				}
				else
				{
					Node* newRoot = new Node;//declare new

					newRoot->id[0] = newleaf_node->id[0];
					newRoot->adress[0] = newleaf_node->adress[0];
					newRoot->dob[0] = newleaf_node->dob[0];
					newRoot->regd[0] = newleaf_node->regd[0];
					newRoot->full_name[0] = newleaf_node->full_name[0];
					newRoot->gender[0] = newleaf_node->gender[0];
					newRoot->qualification[0] = newleaf_node->qualification[0];
					
					newRoot->down[0] = temp_cursor;
					newRoot->down[1] = newleaf_node;
					newRoot->leaf = false;
					newRoot->length = 1;

					root = newRoot;
				}
			}
		}
	}
	//add element//

	//add internal node//
	void addInternal_node(int x,string fn, string db, string rd, string addrs, string qual, string g, Node* temp_cursor, Node* child)//adding internal node//
	{

		int k = 0, l;

		if (temp_cursor->length >= MAX)
		{
			Node* newInternal = new Node;//declare//

			int    virtualid[MAX + 1];////store id
			string virtual_fn[MAX + 1];////store full name 
			string virtual_db[MAX + 1];////store date of birth
			string virtual_rd[MAX + 1];////store reg date
			string virtual_addrs[MAX + 1];////store adress
			string virtual_qual[MAX + 1];////store qual
			string   virtual_g[MAX + 1];////store gender

			Node* virtualdown[MAX + 2];

			while (k < MAX)
			{
				virtualid[k] = temp_cursor->id[k];
			}

			k = 0;
			while (k < MAX + 1)
			{
				virtualdown[k] = temp_cursor->down[k];
			}

			int i = 0, j;
			while (x > virtualid[i] && i < MAX)
			{
				i++;
			}

			j = MAX + 1;
			while (j > i)
			{
				virtualid[j] = virtualid[j - 1];
				j--;
			}

			virtualid[i] = x;///
			virtual_fn[i]=fn;////store full name 
			virtual_db[i]=db;////store date of birth
			virtual_rd[i]=rd;////store reg date
		    virtual_addrs[i]=addrs;////store adress
			virtual_qual[i]=qual;////store qual
			virtual_g[i]=g;////store gender


			l = MAX + 2;

			while (l > i + 1)
			{
				virtualdown[l] = virtualdown[l - 1];
				l--;
			}

			virtualdown[i + 1] = child;

			newInternal->leaf = false;
			temp_cursor->length = (MAX + 1) / 2;
			newInternal->length = MAX - (MAX + 1) / 2;

			i = 0;
			j = temp_cursor->length + 1;
			while (i < newInternal->length)
			{
				newInternal->id[i] = virtualid[j];/////
				
				newInternal->full_name[i] = virtual_fn[j];////store full name 
				newInternal->dob[i] = virtual_db[j];////store date of birth
				newInternal->regd[i] = virtual_rd[j];////store reg date
				newInternal->adress[i] = virtual_addrs[j];////store adress
				newInternal->qualification[i] = virtual_qual[j];////store qual
				newInternal->gender[i] = virtual_g[j];////store gender

				i++;
				j++;
			}
			i = 0;
			j = temp_cursor->length + 1;

			while (i < newInternal->length + 1)
			{
				newInternal->down[i] = virtualdown[j];
				i++;
				j++;
			}

			if (temp_cursor != root)
			{
				addInternal_node(temp_cursor->id[temp_cursor->length],temp_cursor->full_name[temp_cursor->length], temp_cursor->dob[temp_cursor->length], temp_cursor->regd[temp_cursor->length], temp_cursor->adress[temp_cursor->length], temp_cursor->qualification[temp_cursor->length], temp_cursor->gender[temp_cursor->length],findparent_node(root, temp_cursor), newInternal);
			}
			else
			{

				Node* newRoot = new Node;
				
				newRoot->id[0] = temp_cursor->id[temp_cursor->length];////
				newRoot->full_name[0] = temp_cursor->full_name[temp_cursor->length];////
				newRoot->dob[0] = temp_cursor->dob[temp_cursor->length];////
				newRoot->regd[0] = temp_cursor->regd[temp_cursor->length];////
				newRoot->adress[0] = temp_cursor->adress[temp_cursor->length];////
				newRoot->gender[0] = temp_cursor->gender[temp_cursor->length];////
				newRoot->qualification[0] = temp_cursor->qualification[temp_cursor->length];////
				
				newRoot->down[0] = temp_cursor;
				newRoot->down[1] = newInternal;
				newRoot->leaf = false;
				newRoot->length = 1;

				root = newRoot;
			}
		}


		else
		{
			int i = 0, j, k;
			while (x > temp_cursor->id[i] && i < temp_cursor->length)
			{
				i++;
			}

			j = temp_cursor->length;
			while (j > i)
			{
				temp_cursor->id[j] = temp_cursor->id[j - 1];
				j--;
			}

			j = temp_cursor->length + 1;

			while (j > i)
			{
				temp_cursor->down[j] = temp_cursor->down[j - 1];
				j--;
			}

			temp_cursor->id[i] = x;//update idss//
			temp_cursor->full_name[i] = fn;
			temp_cursor->dob[i] = db;
			temp_cursor->regd[i] = rd;
			temp_cursor->adress[i] = addrs;
			temp_cursor->qualification[i] = qual;
			temp_cursor->gender[i] = g;
			 
			temp_cursor->length++;//increment legth
			temp_cursor->down[i + 1] = child;//udate down//
		}
	}
	//add internal node//

	//find parent node//
	Node* findparent_node(Node* temp_cursor, Node* child)
	{
		Node* parent = NULL;
		int i = 0;

		if (temp_cursor->leaf || (temp_cursor->down[0])->leaf) //terminating condition
		{
			return NULL;
		}

		while (i < temp_cursor->length + 1)
		{
			if (temp_cursor->down[i] != child)//is not equall to child//
			{
				parent = findparent_node(temp_cursor->down[i], child);//recursion//
				if (parent != NULL)
				{
					return parent;
				}
			}

			else//equall to child//
			{
				parent = temp_cursor;//update parent //
				return parent;
			}
			i++;
		}
		return parent;
	}
	//find parent node//

	// Print the tree
	void display_tree(Node* temp_cursor)
	{
		int i = 0;
		if (temp_cursor == NULL)//empty
		{

		}
		else
		{
			while (i < temp_cursor->length)
			{
				cout << temp_cursor->id[i] <<"\n";//display id//
				cout << temp_cursor->full_name[i] <<"\n";//display id//
				cout << temp_cursor->dob[i] <<"\n";//display id//
				cout << temp_cursor->regd[i] << "\n";//display id//
				cout << temp_cursor->qualification[i] << "\n";//display id//
				cout << temp_cursor->gender[i] << "\n";//display id//
				cout << temp_cursor->adress[i] << "\n\n";//display id//
				i++;
			}

			cout << "\n";
			if (temp_cursor->leaf == true)
			{
				i = 0;
			}
			else
			{
				i = 0;//declared

				while (i < temp_cursor->length + 1)
				{
					display_tree(temp_cursor->down[i]);//recursion//
					i++;
				}
			}
		}
	}
	// Print the tree

	// Get the root value
	Node* getRoot_val() //output //
	{
		return root;
	}
	 
};



/////////////////////////////////////////////////////PART 2///////////////////////////////////////////
int total_frnd_specific_person = 0;
int total_common_frnd = 0;
int xx = 0, yy = 0;
int to_find = 0;
int level = 0;
int level_time = 1;
int level_id = 0;

class qeue
{
public:
	int q_id;
	qeue* qeue_next;
	qeue()
	{
		q_id = 0;
		qeue_next = NULL;
	}
	qeue(int i)
	{
		q_id = i;
		qeue_next = NULL;
	}

};

class traversed
{
public:
	int t_id;
	traversed* traversed_next;
	traversed()
	{
		t_id = 0;
		traversed_next = NULL;
	}
	traversed(int i)
	{
		t_id = i;
		traversed_next = NULL;
	}

};



class meeting_qeue
{
public:

	int a;
	int b;
	int c;
	meeting_qeue* next;

	meeting_qeue()
	{
		a = 0;
		b = 0;
		c = 0;
		next = NULL;
	}
	meeting_qeue(int x, int y, int z)
	{
		a = x;
		b = y;
		c = z;
		next = NULL;
	}
	~meeting_qeue()
	{
		cout << "destructure called\n";
	}
};

class direct_frnd_first
{
public:
	int id_number;
	direct_frnd_first* next_first_direct_frnd;

	direct_frnd_first()
	{
		id_number = 0;
	}
	direct_frnd_first(int i)
	{
		id_number = i;
	}
	~direct_frnd_first()
	{
		cout << "des";
	}
};

class direct_frnd_second
{
public:
	int id_number;
	direct_frnd_second* next_second_direct_frnd;

	direct_frnd_second()
	{
		id_number = 0;
	}
	direct_frnd_second(int i)
	{
		id_number = i;
	}
	~direct_frnd_second()
	{
		cout << "des";
	}
};

class direct_frnd
{
public:
	int id_number;
	direct_frnd* next_direct_frnd;

	direct_frnd()
	{
		id_number = 0;
	}
	direct_frnd(int i)
	{
		id_number = i;
	}
	~direct_frnd()
	{
		cout << "des";
	}
};


class node
{
public:
	int id;
	int social_distance = 0;
	int social_circle = 0;
	int intersect = 0;
	node* next;
	node* down;

	node()
	{
		id = 0;
		social_distance = 0;
		social_circle = 0;
		intersect = 0;
		next = NULL;
		down = NULL;
	}

	node(int i)
	{
		id = i;
		social_distance = 0;
		social_circle = 0;
		intersect = 0;
		next = NULL;
		down = NULL;
	}
	void set_social_distance(int sd)
	{
		social_distance = sd;
	}
	void set_social_circle(int sc)
	{
		social_circle = sc;
	}

	int get_social_distance()
	{
		return social_distance;
	}
	int get_social_circle()
	{
		return social_circle;
	}

	~node()
	{
		cout << "destructor";
	}
};

class friend_link_list
{
public:

	node* head;
	node* current_down;
	direct_frnd* direct_frnd_head;
	direct_frnd_first* direct_frnd_first_head;
	direct_frnd_second* direct_frnd_second_head;
	meeting_qeue* meeting_qeue_head;
	qeue* qeue_head;
	traversed* traversed_head;

	friend_link_list()
	{
		head = NULL;
		direct_frnd_head = NULL;
		current_down = NULL;
		direct_frnd_first_head = NULL;
		direct_frnd_second_head = NULL;
		qeue_head = NULL;
		traversed_head = NULL;
	}

	//=========================================================================================//
	//=========================================================================================//
	//====================================BFS==================================================//

	bool id_compare_with_traverse(int i)
	{
		traversed* temp = traversed_head;//creat temp for main person adress//
		while (temp != NULL)
		{
			if (temp->t_id == i)
			{
				//cout << " TRAVERSED Same " << temp->t_id << "--->\n";// name of main paerson before : //
				return 1;
			}
			else
			{
				//cout << "\ndif\n";
			}
			temp = temp->traversed_next;//main person ka frnd after : //
		}
		return 0;
	}

	bool id_compare_with_qeue(int i)
	{
		qeue* remp = qeue_head;//creat temp for main person adress//
		while (remp != NULL)
		{
			if (remp->q_id == i)
			{
				//cout << " QEUE Same " << remp->q_id << "--->\n";// name of main paerson before : //
				return 1;
			}
			else
			{
				//cout << "\ndif\n";
			}
			remp = remp->qeue_next;//main person ka frnd after : //
		}
		return 0;
	}
	int specific_person_right_frnd(int i)//find right frnd of specific person//
	{
		int id = 0;
		node* temp = head;//creat temp for main person frnds//
		node* r_temp;// creat r_temp for main person right frnds//

		cout << "\nupdating for level for id = ";
		while (temp != NULL)
		{
			if (temp->id == i)
			{
				cout << i << endl;
				r_temp = temp->next;//main person ka frnd after : //

				while (r_temp != NULL)// display frnd of each person after ://
				{
					id = r_temp->id;
					cout << r_temp->id << "->";
					r_temp = r_temp->next;// next frnd of main person //
					//id = r_temp->id;
				}
				cout << "NULL" << endl;
				return id;
			}
			else
			{

			}
			temp = temp->down;//update to next main person//
		}


	}
	void pass_id_to_qeue(int i)
	{
		bool br = 0;//to break lopp
		bool t = 0, q = 0;//controll which values to pass to qeue always pass unique values to qeue//
		node* temp = head;//creat temp for main person frnds//

		while (temp != NULL)
		{
			if (i == temp->id)//find main person //
			{
				//cout<<"WE  Passed = " << temp->id << "--->\n";
				node* r_temp = temp->next;

				while (r_temp != NULL)
				{
					if (level_time == 1)
					{
						level_id = r_temp->id;
					}

					else
					{

					}
					//cout<< r_temp->id << "--->";
					if (r_temp->id == to_find)// number find//
					{
						br = 1;
						break;
					}
					else/// number not find
					{
						q = id_compare_with_qeue(r_temp->id);//check that id is present in qeue or not 
						t = id_compare_with_traverse(r_temp->id);// check that id is present in traversedd or not
						if (q == 1 || t == 1)//if id is present 
						{
							//		cout << r_temp->id << " not passed \n\n";
						}
						else//if id is unique 
						{
							add_id_in_qeue(r_temp->id);
						}
					}

					if (br == 0)
					{
						r_temp = r_temp->next;//next right person from file//	
					}
					else
					{
						//cout << "\nnumber found\n";
						break;
						r_temp = r_temp->next;//next right person from file//
					}

				}
				level_time = level_time + 1;//to make count for level for first time//

				if (br == 0)
				{
					//cout << "\nQEUE \n";
					show_qeue(0);
				}
				else
				{

				}

			}
			else {}

			if (br == 0)
			{
				temp = temp->down;//update to next main person//
			}
			else
			{
				//cout << "\nnumber found\n";
				break;
				temp = temp->down;//update to next main person//
			}
		}

		if (br == 0)
		{

		}
		else
		{
			exit;
		}
	}


	void add_id_in_qeue(int n)
	{
		//		cout << "\nadding in qeue\n";
		qeue* m = new qeue(n);//creat new node//

		if (qeue_head == NULL)//first node//
		{
			qeue_head = m;
			return;
		}
		else
		{
			qeue* temp = qeue_head;
			while (temp->qeue_next != NULL)
			{
				temp = temp->qeue_next;
			}
			temp->qeue_next = m;
		}


		//	cout << "\nQEUE \n";
		//show_qeue(0);
	}

	void add_id_in_traversed(int n)
	{
		int i;

		if (n == level_id)
		{
			cout << "Level id = " << level_id << endl;
			level = level + 1;
			level_id = specific_person_right_frnd(level_id);
		}
		else
		{

		}
		traversed* m = new traversed(n);//creat new node//

		if (traversed_head == NULL)//first node//
		{

			traversed_head = m;
			i = n;
			// cout << "\nrunnn \n";
			pass_id_to_qeue(i);
			return;
		}
		else
		{
			traversed* temp = traversed_head;
			i = n;
			while (temp->traversed_next != NULL)
			{

				temp = temp->traversed_next;
			}
			temp->traversed_next = m;

			//	cout << "\nrunnn \n";
			pass_id_to_qeue(i);
		}
	}

	void show_qeue(int k)//show direct frnd of specific person //
	{
		int i;

		if (k == 1)
		{
			qeue* temp = qeue_head;//creat temp for main person adress//

			while (temp != NULL)
			{
				//		cout << temp->q_id << "--->";// name of main paerson before : //
				temp = temp->qeue_next;//main person ka frnd after : //
			}
		}

		else
		{
			qeue* temp = qeue_head;//creat temp for main person adress//
			qeue* t = qeue_head;
			qeue_head = qeue_head->qeue_next;//update head before passing to traversed

			while (temp != NULL)
			{
				//	cout << temp->q_id << "--->";// name of main paerson before : //
				temp = temp->qeue_next;//main person ka frnd after : //
			}
			i = t->q_id;
			delete t;
			//cout << "  add element to traversed   \n";
			add_id_in_traversed(i);
			//cout << "\npass to qeue called \n";
			//pass_id_to_qeue(i);
		}
	}

	void show_traversed()//show direct frnd of specific person //
	{
		traversed* temp = traversed_head;//creat temp for main person adress//

		while (temp != NULL)
		{
			//cout << temp->t_id << "--->";// name of main paerson before : //
			temp = temp->traversed_next;//main person ka frnd after : //
		}
	}

	void delete_traversed()//delete entire traversed list//
	{
		traversed* temp = traversed_head;

		while (temp != NULL)
		{
			++total_frnd_specific_person;
			temp = temp->traversed_next;
			free(direct_frnd_head);
			traversed_head = temp;
		}
	}

	void delete_qeue()//delete entire traversed list//
	{
		qeue* temp = qeue_head;

		while (temp != NULL)
		{
			++total_frnd_specific_person;
			temp = temp->qeue_next;
			free(qeue_head);
			qeue_head = temp;
		}
	}

	//=========================================================================================//
	//=========================================================================================//
	//=========================================================================================//

	bool  comparison_with_qeue(int x, int y)//check wheter to skip case 4 current iteration//
	{
		meeting_qeue* temp = meeting_qeue_head;//creat temp = to main person head//

		while (temp != NULL)
		{
			if (x == temp->c || x == temp->b || x == temp->a)//same id found//
			{

				if (y == temp->c || y == temp->b || y == temp->a)//same id found//
				{
					return 0;//hence no need to iterate//

				}
			}

			else
			{

			}

			temp = temp->next;//main person ka frnd after : //
		}
		return 1;////hence  need to iterate//
	}

	bool  same_combination_queue(int z)//check  same frnd is in qeue  //
	{
		meeting_qeue* temp = meeting_qeue_head;//creat temp = to qeue person head//

		while (temp != NULL)
		{
			if (z == temp->c || z == temp->b || z == temp->a)//same id found//
			{

				if (yy == temp->c || yy == temp->b || yy == temp->a)//same id found//
				{
					//cout << "\nyy\n";
					if (xx == temp->c || xx == temp->b || xx == temp->a)//same id found//
					{

						cout << " [  QEUE same FOUND=" << z << "\n";// name od person found in qeue //
						return 1;
					}
				}
			}

			else
			{
			}

			temp = temp->next;//compare next node in qeue //
		}
		return 0;// no same id in whole direct frnd list//
	}
	bool  same_frnd_in_direct_list(int n)//check  same frnd in direct list of  specific person //
	{
		direct_frnd* temp = direct_frnd_head;//creat temp = to main person head//

		while (temp != NULL)
		{
			if (temp->id_number == n)//same id found//
			{
				//cout << " [  same FOUND="<< n<<"";// name of main paerson before : //
				return 1;
			}
			else
			{
			}

			temp = temp->next_direct_frnd;//main person ka frnd after : //
		}
		return 0;// no same id in whole direct frnd list//
	}

	bool  same_frnd_in_direct_list_First(int n)//check  same frnd in direct list of  specific person //
	{
		direct_frnd_first* temp = direct_frnd_first_head;//creat temp = to main person head//

		while (temp != NULL)
		{
			if (temp->id_number == n)//same id found//
			{
				//cout << " [  same FOUND="<< n<<"";// name of main paerson before : //
				return 1;
			}
			else
			{
			}

			temp = temp->next_first_direct_frnd;//main person ka frnd after : //
		}
		return 0;// no same id in whole direct frnd list//
	}
	bool  same_frnd_in_direct_list_Second(int n)//check  same frnd in direct list of  specific person //
	{
		direct_frnd_second* temp = direct_frnd_second_head;//creat temp = to main person head//

		while (temp != NULL)
		{
			if (temp->id_number == n)//same id found//
			{
				//cout << " [  same FOUND="<< n<<"";// name of main paerson before : //
				return 1;
			}
			else
			{
			}

			temp = temp->next_second_direct_frnd;//main person ka frnd after : //
		}
		return 0;// no same id in whole direct frnd list//
	}
	//=========================================================================================//
	//=========================================================================================//
	//=========================================================================================//
	void delete_meeting_qeue()//delete entire dirct frnd list//
	{
		meeting_qeue* temp = meeting_qeue_head;//creat temp for main person down frnds//

		while (temp != NULL)
		{
			++total_frnd_specific_person;
			temp = temp->next;//temp for main person adress//
			free(direct_frnd_head);
			meeting_qeue_head = temp;
		}
	}
	void delete_frnd_direct_list()//delete entire dirct frnd list//
	{
		direct_frnd* temp = direct_frnd_head;//creat temp for main person down frnds//

		while (temp != NULL)
		{
			++total_frnd_specific_person;
			temp = temp->next_direct_frnd;//temp for main person adress//
			free(direct_frnd_head);
			direct_frnd_head = temp;
		}
	}
	void delete_frnd_direct_list_First()//delete entire dirct frnd list//
	{
		direct_frnd_first* temp = direct_frnd_first_head;//creat temp for main person down frnds//

		while (temp != NULL)
		{
			++total_frnd_specific_person;
			temp = temp->next_first_direct_frnd;//temp for main person adress//
			free(direct_frnd_head);
			direct_frnd_first_head = temp;
		}
	}
	void delete_frnd_direct_list_Second()//delete entire dirct frnd list//
	{
		direct_frnd_second* temp = direct_frnd_second_head;//creat temp for main person down frnds//

		while (temp != NULL)
		{
			++total_frnd_specific_person;
			temp = temp->next_second_direct_frnd;//temp for main person adress//
			free(direct_frnd_head);
			direct_frnd_second_head = temp;
		}
	}
	//=========================================================================================//
	//=========================================================================================//
	//=========================================================================================//
	void show_meeting_qeue()//show direct frnd of specific person //
	{
		meeting_qeue* temp = meeting_qeue_head;//creat temp for main person adress//

		while (temp != NULL)
		{
			cout << "[ (" << temp->a << " , " << temp->b << " ,) " << temp->c << " ]" << "--->";// name of main paerson before : //
			temp = temp->next;//main person ka frnd after : //
		}
	}

	void show_frnd_direct_list()//show direct frnd of specific person //
	{
		direct_frnd* temp = direct_frnd_head;//creat temp for main person adress//

		while (temp != NULL)
		{
			//		cout << temp->id_number << "--->";// name of main paerson before : //
			temp = temp->next_direct_frnd;//main person ka frnd after : //
		}
	}
	void show_frnd_direct_list_first()//show direct frnd of specific person //
	{

		direct_frnd_first* temp = direct_frnd_first_head;//creat temp for main person adress//

		while (temp != NULL)
		{
			//	cout << temp->id_number << "--->";// name of main paerson before : //
			temp = temp->next_first_direct_frnd;//main person ka frnd after : //
		}
	}

	void show_frnd_direct_list_second()//show direct frnd of specific person //
	{
		direct_frnd_second* temp = direct_frnd_second_head;//creat temp for main person adress//

		while (temp != NULL)
		{
			//cout << temp->id_number << "--->";// name of main paerson before : //
			temp = temp->next_second_direct_frnd;//main person ka frnd after : //
		}
	}

	void common_frnd_insocial_circle(bool b)
	{
		int z;//for case 4//
		direct_frnd_first* First = direct_frnd_first_head;//creat temp for first main person adress//
		direct_frnd_second* Second;//creat temp for second main person adress//

		while (First != NULL)//till end
		{
			Second = direct_frnd_second_head;//initialize Second with Second person head//

			while (Second != NULL)//till end
			{
				if (Second->id_number == First->id_number)//compare till null
				{
					if (b == 0)// for case 3//
					{
						cout << First->id_number << "--->";// common frnds between first and second person  //
						total_common_frnd = total_common_frnd + 1;
					}
					else// for case 4//
					{
						//z = First->id_number;
						total_common_frnd = total_common_frnd + 1;
						//cout << First->id_number << "--->";// common frnds between first and second person  //
						//add_meeting_qeue(z);

					}
				}
				else
				{

				}
				Second = Second->next_second_direct_frnd;//update second frnd 
			}

			//cout << First->id_number << "--->";// name of main paerson before : //

			First = First->next_first_direct_frnd;//main person ka frnd after : //
		}
	}

	//=========================================================================================//
	//=========================================================================================//
	//=========================================================================================//

	void add_meeting_qeue(int z)//insert direct frnds of specific  person//
	{
		bool found = 0;

		found = same_combination_queue(z);//check is there any frnd  repeating//

		meeting_qeue* m = new meeting_qeue(xx, yy, z);//creat new node//

		if (meeting_qeue_head == NULL)//first node//
		{
			meeting_qeue_head = m;

			return;
		}

		else if (meeting_qeue_head != NULL && found == 0)//new node and no frnd repeating //
		{
			meeting_qeue* temp = meeting_qeue_head;//create//
			while (temp->next != NULL)// insert new  node right in list//
			{
				temp = temp->next;
			}
			temp->next = m;
		}
		else//direct frnd repeating //
		{
			//cout << "===SKIP=== " << z << " ] ";
		}
	}

	void add_frnd_in_direct_list(int n)//insert direct frnds of specific  person//
	{
		bool found = 0;
		found = same_frnd_in_direct_list(n);//check is there any frnd  repeating//

		direct_frnd* m = new direct_frnd(n);//creat new node//

		if (direct_frnd_head == NULL)//first node//
		{
			direct_frnd_head = m;
			return;
		}

		else if (direct_frnd_head != NULL && found == 0)//new node and no frnd repeating //
		{
			direct_frnd* temp = direct_frnd_head;//create//
			while (temp->next_direct_frnd != NULL)// insert new  node right in list//
			{
				temp = temp->next_direct_frnd;
			}
			temp->next_direct_frnd = m;
		}
		else//direct frnd repeating //
		{
			//cout << "===SKIP=== "<<n<<" ] ";
		}
	}


	void add_frnd_in_direct_list_First(int n)//insert direct frnds of specific  person//
	{
		bool found = 0;
		found = same_frnd_in_direct_list_First(n);//check is there any frnd  repeating//

		direct_frnd_first* m = new direct_frnd_first(n);//creat new node//

		if (direct_frnd_first_head == NULL)//first node//
		{
			direct_frnd_first_head = m;
			return;
		}

		else if (direct_frnd_first_head != NULL && found == 0)//new node and no frnd repeating //
		{

			direct_frnd_first* temp = direct_frnd_first_head;//create//
			while (temp->next_first_direct_frnd != NULL)// insert new  node right in list//
			{
				temp = temp->next_first_direct_frnd;
			}
			temp->next_first_direct_frnd = m;
		}
		else//direct frnd repeating //
		{
			//cout << "===SKIP=== "<<n<<" ] ";
		}
	}
	void add_frnd_in_direct_list_Second(int n)//insert direct frnds of specific  person//
	{
		bool found = 0;
		found = same_frnd_in_direct_list_Second(n);//check is there any frnd  repeating//

		direct_frnd_second* m = new direct_frnd_second(n);//creat new node//

		if (direct_frnd_second_head == NULL)//first node//
		{
			direct_frnd_second_head = m;
			return;
		}

		else if (direct_frnd_second_head != NULL && found == 0)//new node and no frnd repeating //
		{
			direct_frnd_second* temp = direct_frnd_second_head;//create//
			while (temp->next_second_direct_frnd != NULL)// insert new  node right in list//
			{
				temp = temp->next_second_direct_frnd;
			}
			temp->next_second_direct_frnd = m;
		}
		else//direct frnd repeating //
		{
			//cout << "===SKIP=== "<<n<<" ] ";
		}
	}
	//=======================================================================================//
	//=======================================================================================//
	//=======================================================================================//
	void find_social_circle_p(int n, int first, int& c_f)//social circle of specific person//
	{
		node* temp = head;//creat temp for main person down frnds//
		node* r_temp;// creat r_temp for main person right frnds//
		bool main_person_find = 0;
		int i;

		while (temp != NULL)
		{
			if (temp->id == n)
			{
				//cout << temp->id << "--->";// name of main paerson before : //
				main_person_find = 1;

				r_temp = temp->next;//r_temp = main person ka first right frnd //

				while (r_temp != NULL)// display frnd of each person after ://
				{
					//cout << r_temp->id << "->";
					i = r_temp->id;

					if (first == 1)// inorder to calclutate direct frnd//
					{
						c_f++;
						add_frnd_in_direct_list(i);
					}
					else if (first == 0)
					{
						add_frnd_in_direct_list(i);
					}

					r_temp = r_temp->next;// next right frnd of main person //
				}
				//cout << "NULL" << endl;
				temp = temp->down;//update to down main person//
			}
			else
			{
				temp = temp->down;//update to down main person//
			}
		}

		//cout << "\nend\n";
		//find_social_circle(2499);
		//show_frnd_direct_list();
	}
	void find_social_circle_p_First(int n, int first, int& c_f)//social circle of specific person//
	{
		node* temp = head;//creat temp for main person down frnds//
		node* r_temp;// creat r_temp for main person right frnds//
		bool main_person_find = 0;
		int i;

		while (temp != NULL)
		{
			if (temp->id == n)
			{
				//	cout << temp->id << "--->";// name of main paerson before : //
				main_person_find = 1;

				r_temp = temp->next;//r_temp = main person ka first right frnd //

				while (r_temp != NULL)// display frnd of each person after ://
				{
					//	cout << r_temp->id << "->";
					i = r_temp->id;

					if (first == 1)// inorder to calclutate direct frnd//
					{
						c_f++;
						add_frnd_in_direct_list_First(i);
					}
					else if (first == 0)
					{
						add_frnd_in_direct_list_First(i);
					}
					r_temp = r_temp->next;// next right frnd of main person //
				}
				//cout << "NULL" << endl;
				temp = temp->down;//update to down main person//
			}
			else
			{
				temp = temp->down;//update to down main person//
			}
		}

		//cout << "\nend\n";
		//find_social_circle(2499);
		//show_frnd_direct_list();
	}

	void find_social_circle_p_Second(int n, int first, int& c_f)//social circle of specific person//
	{
		node* temp = head;//creat temp for main person down frnds//
		node* r_temp;// creat r_temp for main person right frnds//
		bool main_person_find = 0;
		int i;

		while (temp != NULL)
		{
			if (temp->id == n)
			{
				//	cout << temp->id << "--->";// name of main paerson before : //
				main_person_find = 1;

				r_temp = temp->next;//r_temp = main person ka first right frnd //

				while (r_temp != NULL)// display frnd of each person after ://
				{
					//	cout << r_temp->id << "->";
					i = r_temp->id;

					if (first == 1)// inorder to calclutate direct frnd//
					{
						c_f++;
						add_frnd_in_direct_list_Second(i);
					}
					else if (first == 0)
					{
						add_frnd_in_direct_list_Second(i);
					}

					r_temp = r_temp->next;// next right frnd of main person //
				}
				//cout << "NULL" << endl;
				temp = temp->down;//update to down main person//
			}
			else
			{
				temp = temp->down;//update to down main person//
			}
		}

		//cout << "\nend\n";
		//find_social_circle(2499);
		//show_frnd_direct_list();
	}
	//=======================================================================================//
	//=======================================================================================//
	//=======================================================================================//

	void find_social_circle_of_specific_person(int n)
	{
		int c_f = 1;//count frnd of specific person
		int first = 1;//when lopp run for first time bcz it will count direct frnd of specific person//
		int count = 1;//intitial starting point/count//
		int max_count = 1;//maximun frnd of specific person//
		int k;

		find_social_circle_p(n, first, c_f);// CALL FOR FIRST TIME
		max_count = c_f - 1;//max_count=direct friend number//
		direct_frnd* temp = direct_frnd_head;//creat temp for main person down frnds//
		//cout << "\n\n\n\n"<<"DIRECT FRIENDS =" << max_count << "\n\n\n\n\n";

		while (count <= max_count)//while<direct friends
		{
			first = 0;//direct frnd has been calclutated so no use of first further//
			count++;
			//cout<<"[ " << temp->id_number << " ]"; // name of main person direct frnd //
			k = temp->id_number;
			//cout << "\n#######################################\n";
			find_social_circle_p(k, first, c_f);
			temp = temp->next_direct_frnd;// name of main person direct frnd->next //
		}
	}

	void find_social_circle_of_specific_person_First(int n)
	{
		int c_f = 1;//count frnd of specific person
		int first = 1;//when lopp run for first time bcz it will count direct frnd of specific person//
		int count = 1;//intitial starting point/count//
		int max_count = 1;//maximun frnd of specific person//
		int k;

		find_social_circle_p_First(n, first, c_f);// CALL FOR FIRST TIME
		max_count = c_f - 1;//max_count=direct friend number//
		direct_frnd_first* temp = direct_frnd_first_head;//creat temp for main person down frnds//
		//cout << "\n\n\n\n" << "DIRECT FRIENDS =" << max_count << "\n\n\n\n\n";
		while (count <= max_count)//while<direct friends
		{
			first = 0;//direct frnd has been calclutated so no use of first further//
			count++;
			//cout<<"[ " << temp->id_number << " ]"; // name of main person direct frnd //
			k = temp->id_number;
			//cout << "\n#######################################\n";
			find_social_circle_p_First(k, first, c_f);
			temp = temp->next_first_direct_frnd;// name of main person direct frnd->next //
		}
	}
	void find_social_circle_of_specific_person_Second(int n)
	{
		int c_f = 1;//count frnd of specific person
		int first = 1;//when lopp run for first time bcz it will count direct frnd of specific person//
		int count = 1;//intitial starting point/count//
		int max_count = 1;//maximun frnd of specific person//
		int k;

		find_social_circle_p_Second(n, first, c_f);// CALL FOR FIRST TIME
		max_count = c_f - 1;//max_count=direct friend number//
		direct_frnd_second* temp = direct_frnd_second_head;//creat temp for main person down frnds//
		//cout << "\n\n\n\n" << "DIRECT FRIENDS =" << max_count << "\n\n\n\n\n";
		while (count <= max_count)//while<direct friends
		{
			first = 0;//direct frnd has been calclutated so no use of first further//
			count++;
			//cout<<"[ " << temp->id_number << " ]"; // name of main person direct frnd //
			k = temp->id_number;
			//cout << "\n#######################################\n";
			find_social_circle_p_Second(k, first, c_f);
			temp = temp->next_second_direct_frnd;// name of main person direct frnd->next //
		}
	}
	//=======================================================================================//
	//=======================================================================================//
	//=======================================================================================//

	void add_person(int n, bool insert_down, bool insert_right)//insert person in list
	{
		node* m = new node(n);
		if (head == NULL)
		{
			head = m;
			current_down = m;

			return;
		}

		else if (head != NULL && insert_down == 1 && insert_right == 0)
		{
			node* temp = head;//create//

			while (temp->down != NULL)// insert new  node below in list//
			{
				temp = temp->down;
			}
			temp->down = m;
			current_down = m;
		}
		else if (head != NULL && insert_down == 0 && insert_right == 1)
		{
			node* temp = current_down;//create//

			while (temp->next != NULL)// insert new  node right in list//
			{
				temp = temp->next;
			}
			temp->next = m;
		}
	}

	void get_person_with_largest_social_circle()
	{
		int max = 0;
		max = head->social_circle;
		int id = head->id;
		node* temp = head;//creat temp for main person down frnds//

		while (temp != NULL)
		{
			if (max < temp->social_circle)
			{
				max = temp->social_circle;
				id = temp->id;
			}
			else
			{

			}
			temp = temp->down;//update to next main person//
		}

		cout << "id " << id << " has max social circle = " << max << " friends" << endl;
	}

	void set_specific_person_social_circle(int t)
	{
		node* temp = head;//creat temp for main person down frnds//

		while (temp != NULL)
		{
			if (temp->id == t)
			{
				temp->set_social_circle(total_frnd_specific_person);
				//cout << temp->id << "= " << temp->social_circle << "  --->";// name of main paerson before : //
			}
			else
			{
			}
			temp = temp->down;//update to next main person//
		}
	}

	void show_whole_list_frnd() // display all frnd list//
	{
		node* temp = head;//creat temp for main person down frnds//
		node* r_temp;// creat r_temp for main person right frnds//

		while (temp != NULL)
		{
			cout << temp->id << "= " << temp->social_circle << "  --->";// name of main paerson before : //
			r_temp = temp->next;//main person ka frnd after : //

			while (r_temp != NULL)// display frnd of each person after ://
			{
				cout << r_temp->id << "->";
				r_temp = r_temp->next;// next frnd of main person //
			}
			cout << "NULL" << endl;

			temp = temp->down;//update to next main person//
		}
	}

	~friend_link_list()
	{
		cout << "frnd destructor ";
	}

};

